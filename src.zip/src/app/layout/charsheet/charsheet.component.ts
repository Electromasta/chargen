import { Component } from '@angular/core';

@Component({
  selector: 'charsheet',
  standalone: false,
  
  templateUrl: './charsheet.component.html',
  styleUrl: './charsheet.component.css'
})
export class CharsheetComponent {

}
