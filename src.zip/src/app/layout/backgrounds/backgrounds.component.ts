import { Component } from '@angular/core';

@Component({
  selector: 'backgrounds',
  standalone: false,
  templateUrl: './backgrounds.component.html',
  styleUrl: './backgrounds.component.css'
})
export class BackgroundsComponent {
  tiles = [
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
    { title: 'Noble', imageUrl: 'https://placehold.co/100x75' },
  ];
}
